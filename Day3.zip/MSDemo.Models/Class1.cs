﻿using System;

namespace MSDemo.Models
{
    public class Car
    {
        public int Id { get; set; }
        public string Brand { get; set; }
        public double Price { get; set; }
    }
}
